-- ============================================================
-- DATABASE SCHEME & DATA AWAL SI-BANSOS KABUPATEN BIREUEN
-- Import file ini melalui phpMyAdmin atau MySQL CLI di Web Hosting
-- ============================================================

CREATE DATABASE IF NOT EXISTS `db_sibansos_bireuen` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `db_sibansos_bireuen`;

-- --------------------------------------------------------
-- 1. TABEL PROGRAM BANSOS
-- --------------------------------------------------------
DROP TABLE IF EXISTS `program_bansos`;
CREATE TABLE `program_bansos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode_program` varchar(20) NOT NULL UNIQUE,
  `nama_program` varchar(100) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `penyelenggara` varchar(100) NOT NULL,
  `nominal_bantuan` varchar(100) DEFAULT NULL,
  `periode` varchar(50) DEFAULT NULL,
  `kuota_nasional_daerah` int(11) DEFAULT 0,
  `status` enum('Aktif','Non-Aktif') DEFAULT 'Aktif',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `program_bansos` (`id`, `kode_program`, `nama_program`, `deskripsi`, `penyelenggara`, `nominal_bantuan`, `periode`, `kuota_nasional_daerah`, `status`) VALUES
(1, 'PKH', 'Program Keluarga Harapan (PKH)', 'Bantuan sosial bersyarat kepada Keluarga Miskin (KM) yang ditetapkan sebagai keluarga penerima manfaat.', 'Kementerian Sosial RI', 'Rp 225.000 - Rp 750.000 / Tahap', 'Triwulan (4 Tahap / Tahun)', 18450, 'Aktif'),
(2, 'BPNT', 'Bantuan Pangan Non-Tunai (Sembako)', 'Bantuan pangan dalam bentuk uang tunai/saldo elektronik untuk pembelian bahan pokok beras dan telur.', 'Kementerian Sosial RI', 'Rp 200.000 / Bulan', 'Setiap Bulan', 24200, 'Aktif'),
(3, 'BLT-DD', 'Bantuan Langsung Tunai Dana Desa', 'Pemberian uang tunai kepada keluarga miskin di desa bersumber dari Dana Desa untuk mengurangi dampak ekonomi.', 'Pemerintah Desa / Gampong', 'Rp 300.000 / Bulan', 'Setiap Bulan', 12100, 'Aktif'),
(4, 'BANSOS-PANGAN', 'Bantuan Cadangan Pangan Beras 10Kg', 'Bantuan beras cadangan pemerintah 10 kg per KPM untuk menjaga ketahanan pangan masyarakat miskin.', 'Badan Pangan Nasional & Perum BULOG', '10 Kg Beras Medium / Bulan', 'Bulanan', 31500, 'Aktif');

-- --------------------------------------------------------
-- 2. TABEL PENERIMA BANSOS (DTKS)
-- --------------------------------------------------------
DROP TABLE IF EXISTS `penerima_bansos`;
CREATE TABLE `penerima_bansos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(16) NOT NULL UNIQUE,
  `nkk` varchar(16) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `alamat` text NOT NULL,
  `gampong` varchar(100) NOT NULL,
  `kecamatan` varchar(100) NOT NULL,
  `kabupaten` varchar(100) DEFAULT 'Kabupaten Bireuen',
  `pekerjaan` varchar(100) DEFAULT NULL,
  `penghasilan_bulanan` int(11) DEFAULT 0,
  `jumlah_tanggungan` int(11) DEFAULT 1,
  `program_diterima` varchar(100) NOT NULL,
  `status_verifikasi` enum('Terverifikasi','Proses Verifikasi','Ditolak') DEFAULT 'Terverifikasi',
  `status_penyaluran` enum('Tersalurkan','Siap Salur','Tertunda') DEFAULT 'Tersalurkan',
  `tanggal_penyaluran_terakhir` date DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_nik` (`nik`),
  KEY `idx_kecamatan` (`kecamatan`),
  KEY `idx_program` (`program_diterima`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `penerima_bansos` (`id`, `nik`, `nkk`, `nama_lengkap`, `jenis_kelamin`, `alamat`, `gampong`, `kecamatan`, `pekerjaan`, `penghasilan_bulanan`, `jumlah_tanggungan`, `program_diterima`, `status_verifikasi`, `status_penyaluran`, `tanggal_penyaluran_terakhir`, `keterangan`) VALUES
(1, '1111011504820001', '1111012003050012', 'Teuku Iskandar Muda', 'L', 'Jl. T. Hamzah Bendahara No. 12', 'Gampong Kota Bireuen', 'Kota Juang', 'Buruh Harian Lepas', 850000, 4, 'PKH', 'Terverifikasi', 'Tersalurkan', '2026-07-15', 'Tersalurkan lewat PT Pos Indonesia'),
(2, '1111025208850003', '1111021406080045', 'Cut Nurhayati', 'P', 'Dusun Matang Mesjid', 'Matangglumpangdua', 'Peusangan', 'Pedagang Kecil', 950000, 3, 'BPNT', 'Terverifikasi', 'Tersalurkan', '2026-07-20', 'Penyaluran via Bank BSI'),
(3, '1111030811780002', '1111031902040089', 'Muhammad Dahlan', 'L', 'Jl. Banda Aceh - Medan Km. 210', 'Keude Samalanga', 'Samalanga', 'Petani', 700000, 5, 'BLT-DD', 'Terverifikasi', 'Tersalurkan', '2026-08-01', 'Tersalurkan oleh Kantor Keuchik'),
(4, '1111044403910005', '1111042509120034', 'Siti Rahmah', 'P', 'Dusun Cot Teube', 'Gandapura', 'Gandapura', 'Mengurus Rumah Tangga', 600000, 4, 'BANSOS-PANGAN', 'Terverifikasi', 'Tersalurkan', '2026-08-05', 'Beras 10kg diterima di Balai Desa'),
(5, '1111051210800004', '1111050207030021', 'Zulkifli Ahmad', 'L', 'Dusun Buket Rumiya', 'Juli Paseh', 'Juli', 'Pekebun', 900000, 3, 'PKH', 'Terverifikasi', 'Siap Salur', '2026-06-12', 'Jadwal pencairan tahap berikutnya'),
(6, '1111066105890006', '1111061801100077', 'Fatimah Azzahra', 'P', 'Dusun Krueng Simpo', 'Peudada', 'Peudada', 'Nelayan / Pengolah Ikan', 750000, 4, 'BPNT', 'Terverifikasi', 'Tersalurkan', '2026-07-18', 'Penyaluran via e-Warong BSI'),
(7, '1111072202750001', '1111071111010055', 'Husaini Zakaria', 'L', 'Dusun Blang Seupeung', 'Jeunieb', 'Jeunieb', 'Buruh Tani', 650000, 5, 'BLT-DD', 'Terverifikasi', 'Tersalurkan', '2026-08-02', 'Disalurkan oleh Perangkat Gampong'),
(8, '1111084907930008', '1111080404150066', 'Marlina Usman', 'P', 'Dusun Pandrah Jantho', 'Pandrah', 'Pandrah', 'Jual Jajanan', 500000, 2, 'BANSOS-PANGAN', 'Proses Verifikasi', 'Tertunda', NULL, 'Perlu pemutakhiran data KK terbaru'),
(9, '1111091708870009', '1111092809090033', 'Bhaktiar Ismail', 'L', 'Dusun Leubu', 'Makmur', 'Makmur', 'Petani Sawit', 1000000, 3, 'PKH', 'Terverifikasi', 'Tersalurkan', '2026-07-10', 'Rekening BSI aktif'),
(10, '1111106312900007', '1111101505110044', 'Nuraini Sulaiman', 'P', 'Dusun Kuta Blang Batee', 'Kuta Blang', 'Kuta Blang', 'Wiraswasta Kecil', 800000, 3, 'BPNT', 'Terverifikasi', 'Tersalurkan', '2026-07-25', 'Tersalurkan secara berkala');

-- --------------------------------------------------------
-- 3. TABEL USULAN MANDIRI (PENGAJUAN WARGA)
-- --------------------------------------------------------
DROP TABLE IF EXISTS `usulan_bansos`;
CREATE TABLE `usulan_bansos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_usulan` varchar(30) NOT NULL UNIQUE,
  `nik` varchar(16) NOT NULL,
  `nama_pengusul` varchar(100) NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `kecamatan` varchar(100) NOT NULL,
  `gampong` varchar(100) NOT NULL,
  `alamat_lengkap` text NOT NULL,
  `program_diusulkan` varchar(100) NOT NULL,
  `alasan_pengajuan` text NOT NULL,
  `status` enum('Menunggu Verifikasi','Disetujui','Ditolak') DEFAULT 'Menunggu Verifikasi',
  `catatan_petugas` text DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `usulan_bansos` (`id`, `no_usulan`, `nik`, `nama_pengusul`, `no_hp`, `kecamatan`, `gampong`, `alamat_lengkap`, `program_diusulkan`, `alasan_pengajuan`, `status`, `catatan_petugas`) VALUES
(1, 'USL-202608-001', '1111010101900009', 'Munawar Abdullah', '085260112233', 'Kota Juang', 'Geudong-Geudong', 'Jl. Elang No. 45 Bireuen', 'PKH', 'Penghasilan menurun drastis akibat sakit menahun dan menanggung 4 anak sekolah.', 'Menunggu Verifikasi', 'Jadwal survei lapangan Dinas Sosial minggu ini'),
(2, 'USL-202608-002', '1111020203880007', 'Syarifah Hanum', '081269887766', 'Peusangan', 'Paya Lipah', 'Dusun Mawar Paya Lipah', 'BPNT', 'Belum pernah mendapat bantuan sosial dan tergolong keluarga kurang mampu di Gampong.', 'Disetujui', 'Data dimasukkan dalam usulan DTKS periode berikutnya');

-- --------------------------------------------------------
-- 4. TABEL PENGADUAN & ASPIRASI (LAPOR BANSOS)
-- --------------------------------------------------------
DROP TABLE IF EXISTS `pengaduan`;
CREATE TABLE `pengaduan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` varchar(30) NOT NULL UNIQUE,
  `nama_pelapor` varchar(100) NOT NULL,
  `email_hp` varchar(100) NOT NULL,
  `kategori` enum('Pungli / Pemotongan','Salah Sasaran','Bantuan Belum Cair','Data Tidak Sesuai','Lainnya') NOT NULL,
  `kecamatan` varchar(100) NOT NULL,
  `isi_laporan` text NOT NULL,
  `status` enum('Baru','Diproses','Selesai','Ditolak') DEFAULT 'Baru',
  `tanggapan_admin` text DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `pengaduan` (`id`, `ticket_id`, `nama_pelapor`, `email_hp`, `kategori`, `kecamatan`, `isi_laporan`, `status`, `tanggapan_admin`) VALUES
(1, 'TCK-88201', 'Hasan Basri', '082361009988', 'Bantuan Belum Cair', 'Samalanga', 'Sudah terdaftar di DTKS tetapi saldo bantuan BPNT bulan Juli belum masuk ke KKS BSI.', 'Diproses', 'Tim Posko Bansos sedang mengkoordinasikan dengan pihak Bank BSI Cabang Bireuen.'),
(2, 'TCK-88202', 'Rahmat Hidayat', 'rahmathdyt@gmail.com', 'Salah Sasaran', 'Kota Juang', 'Mohon verifikasi ulang data penerima BLT di lingkungan tempat tinggal kami karena ada warga mampu yang terdata.', 'Selesai', 'Terima kasih atas laporannya. Tim Verifikator telah melakukan Musdes ulang.');

-- --------------------------------------------------------
-- 5. TABEL USER ADMIN / PETUGAS
-- --------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL UNIQUE,
  `password_hash` varchar(255) NOT NULL,
  `nama_petugas` varchar(100) NOT NULL,
  `role` enum('Super Admin','Operator Dinas','Petugas Kecamatan') DEFAULT 'Operator Dinas',
  `kecamatan_tugas` varchar(100) DEFAULT 'Kabupaten Bireuen',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Password default: 'admin123' (hash MD5/Bcrypt sample)
INSERT INTO `users` (`id`, `username`, `password_hash`, `nama_petugas`, `role`, `kecamatan_tugas`) VALUES
(1, 'admin', '$2y$10$4nC0F5Jc.Yd.3mJ4O.4QCeZ44H8L44O0K5e0z00z00z00z00z00z0', 'Administrator Dinsos Bireuen', 'Super Admin', 'Semua Kecamatan'),
(2, 'operator_kotajuang', '$2y$10$4nC0F5Jc.Yd.3mJ4O.4QCeZ44H8L44O0K5e0z00z00z00z00z00z0', 'Petugas Kota Juang', 'Petugas Kecamatan', 'Kota Juang');
