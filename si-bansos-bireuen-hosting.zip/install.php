<?php
/**
 * SI-BANSOS KABUPATEN BIREUEN - WEB INSTALLER WIZARD
 * Web-based installation wizard to set up database & config automatically.
 */

session_start();

$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$error = '';
$success = '';

// Path ke file penting
$configFile = __DIR__ . '/config.php';
$sqlFile = __DIR__ . '/database.sql';

// ----------------------------------------------------------------------
// ACTION STEP 2: PROSES KONEKSI & IMPORT DATABASE
// ----------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_install'])) {
    $db_host = trim($_POST['db_host']);
    $db_name = trim($_POST['db_name']);
    $db_user = trim($_POST['db_user']);
    $db_pass = trim($_POST['db_pass']);

    if (empty($db_host) || empty($db_name) || empty($db_user)) {
        $error = 'Harap isi Host, Nama Database, dan Username Database!';
    } else {
        try {
            // 1. Tes Koneksi ke Server MySQL
            $pdo = new PDO("mysql:host=$db_host;charset=utf8mb4", $db_user, $db_pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
            ]);

            // 2. Buat Database jika belum ada
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `$db_name`");

            // 3. Baca dan Eksekusi SQL File
            if (!file_exists($sqlFile)) {
                throw new Exception("File database.sql tidak ditemukan di direktori website.");
            }

            $sqlContent = file_get_contents($sqlFile);
            
            // Eksekusi query secara bertahap
            $statements = array_filter(array_map('trim', explode(';', $sqlContent)));
            foreach ($statements as $stmt) {
                if (!empty($stmt) && strpos($stmt, 'CREATE DATABASE') === false && strpos($stmt, 'USE `') === false) {
                    $pdo->exec($stmt);
                }
            }

            // 4. Update File config.php
            $configContent = "<?php\n";
            $configContent .= "/**\n";
            $configContent .= " * Konfigurasi Database & Aplikasi SI BANSOS Kabupaten Bireuen\n";
            $configContent .= " * Di-generate otomatis oleh Web Installer\n";
            $configContent .= " */\n\n";
            $configContent .= "// Konfigurasi Database MySQL\n";
            $configContent .= "define('DB_HOST', " . var_export($db_host, true) . ");\n";
            $configContent .= "define('DB_USER', " . var_export($db_user, true) . ");\n";
            $configContent .= "define('DB_PASS', " . var_export($db_pass, true) . ");\n";
            $configContent .= "define('DB_NAME', " . var_export($db_name, true) . ");\n\n";
            $configContent .= "// Pengaturan Aplikasi\n";
            $configContent .= "define('APP_NAME', 'SI-BANSOS Kabupaten Bireuen');\n";
            $configContent .= "define('APP_TAGLINE', 'Sistem Informasi Data Terpadu Kesejahteraan Sosial & Penyaluran Bantuan Sosial');\n";
            $configContent .= "define('DISTRICT_NAME', 'Kabupaten Bireuen');\n";
            $configContent .= "define('PROVINCE_NAME', 'Aceh');\n\n";
            $configContent .= "// Function Koneksi Database PDO\n";
            $configContent .= "function getDBConnection() {\n";
            $configContent .= "    static \$pdo = null;\n";
            $configContent .= "    if (\$pdo === null) {\n";
            $configContent .= "        try {\n";
            $configContent .= "            \$dsn = \"mysql:host=\" . DB_HOST . \";dbname=\" . DB_NAME . \";charset=utf8mb4\";\n";
            $configContent .= "            \$options = [\n";
            $configContent .= "                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,\n";
            $configContent .= "                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,\n";
            $configContent .= "                PDO::ATTR_EMULATE_PREPARES   => false,\n";
            $configContent .= "            ];\n";
            $configContent .= "            \$pdo = new PDO(\$dsn, DB_USER, DB_PASS, \$options);\n";
            $configContent .= "        } catch (PDOException \$e) {\n";
            $configContent .= "            return null;\n";
            $configContent .= "        }\n";
            $configContent .= "    }\n";
            $configContent .= "    return \$pdo;\n";
            $configContent .= "}\n\n";
            $configContent .= "header(\"X-XSS-Protection: 1; mode=block\");\n";
            $configContent .= "header(\"X-Content-Type-Options: nosniff\");\n";
            $configContent .= "header(\"X-Frame-Options: SAMEORIGIN\");\n";
            $configContent .= "?>\n";

            file_put_contents($configFile, $configContent);

            // Pindah ke Step 3 (Selesai)
            header("Location: install.php?step=3");
            exit();

        } catch (Exception $e) {
            $error = 'Gagal melakukan instalasi: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Installer Website | SI-BANSOS Kabupaten Bireuen</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    body { background: #0f172a; color: #f8fafc; font-family: 'Plus Jakarta Sans', sans-serif; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
    .install-card { background: white; color: #1e293b; max-width: 650px; width: 100%; border-radius: 18px; padding: 40px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5); }
    .step-indicator { display: flex; justify-content: space-between; margin-bottom: 30px; border-bottom: 2px solid #e2e8f0; padding-bottom: 15px; }
    .step-item { font-weight: 700; font-size: 0.85rem; color: #94a3b8; }
    .step-item.active { color: #059669; }
    .alert-danger { background: #fee2e2; color: #991b1b; padding: 14px; border-radius: 8px; margin-bottom: 20px; font-weight: 600; font-size: 0.9rem; }
    .alert-success { background: #dcfce7; color: #166534; padding: 14px; border-radius: 8px; margin-bottom: 20px; font-weight: 600; font-size: 0.9rem; }
    .check-item { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px dashed #e2e8f0; font-size: 0.9rem; }
  </style>
</head>
<body>

  <div class="install-card">
    <div style="text-align:center; margin-bottom:24px;">
      <div class="brand-emblem" style="margin: 0 auto 12px; width:56px; height:56px; font-size:1.6rem;">SB</div>
      <h2 style="font-weight:800; color:#0f172a; font-size:1.6rem;">Web Installer SI-BANSOS</h2>
      <p style="color:#64748b; font-size:0.9rem;">Pemasangan Otomatis Website Kabupaten Bireuen</p>
    </div>

    <!-- Step Progress -->
    <div class="step-indicator">
      <div class="step-item <?php echo $step === 1 ? 'active' : ''; ?>">1. Cek Persyaratan</div>
      <div class="step-item <?php echo $step === 2 ? 'active' : ''; ?>">2. Setup Database</div>
      <div class="step-item <?php echo $step === 3 ? 'active' : ''; ?>">3. Selesai</div>
    </div>

    <?php if ($error): ?>
      <div class="alert-danger">⚠️ <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <!-- STEP 1: PRASYARAT SERVER -->
    <?php if ($step === 1): ?>
      <h3 style="font-size:1.15rem; font-weight:700; margin-bottom:16px;">Pemeriksaan Persyaratan Server</h3>
      
      <div class="check-item">
        <span>Versi PHP (Minimal 7.4)</span>
        <strong><?php echo PHP_VERSION; ?> (OK)</strong>
      </div>
      <div class="check-item">
        <span>Ekstensi PDO MySQL</span>
        <strong><?php echo extension_loaded('pdo_mysql') ? '✅ Tersedia' : '❌ Tidak Aktif'; ?></strong>
      </div>
      <div class="check-item">
        <span>Izin Tulis Config File (config.php)</span>
        <strong><?php echo is_writable($configFile) ? '✅ Writable' : '⚠️ Perlu Izin Tulis'; ?></strong>
      </div>
      <div class="check-item">
        <span>File Skema database.sql</span>
        <strong><?php echo file_exists($sqlFile) ? '✅ Ditemukan' : '❌ Hilang'; ?></strong>
      </div>

      <div style="margin-top:30px; text-align:right;">
        <a href="install.php?step=2" class="btn btn-primary" style="width:100%;">Lanjutkan ke Setup Database ➔</a>
      </div>

    <!-- STEP 2: FORM SETUP DATABASE -->
    <?php elseif ($step === 2): ?>
      <h3 style="font-size:1.15rem; font-weight:700; margin-bottom:12px;">Konfigurasi Database MySQL</h3>
      <p style="font-size:0.875rem; color:#64748b; margin-bottom:20px;">Masukkan kredensial database MySQL hosting Anda (cPanel/phpMyAdmin).</p>

      <form action="install.php?step=2" method="POST">
        <div class="form-group">
          <label class="form-label">Database Host</label>
          <input type="text" name="db_host" class="form-control" value="localhost" required>
          <small style="color:#64748b;">Biasanya `localhost` untuk shared hosting cPanel.</small>
        </div>

        <div class="form-group">
          <label class="form-label">Nama Database MySQL</label>
          <input type="text" name="db_name" class="form-control" value="db_sibansos_bireuen" required placeholder="Contoh: user_db_sibansos">
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
          <div class="form-group">
            <label class="form-label">Username Database</label>
            <input type="text" name="db_user" class="form-control" value="root" required placeholder="root / username_db">
          </div>
          <div class="form-group">
            <label class="form-label">Password Database</label>
            <input type="password" name="db_pass" class="form-control" placeholder="Password MySQL hosting">
          </div>
        </div>

        <div style="margin-top:24px;">
          <button type="submit" name="action_install" class="btn btn-primary" style="width:100%;">🚀 Mulai Import & Install Sekarang</button>
        </div>
      </form>

    <!-- STEP 3: SELESAI -->
    <?php elseif ($step === 3): ?>
      <div style="text-align:center; padding:20px 0;">
        <div style="font-size:3.5rem; margin-bottom:10px;">🎉</div>
        <h3 style="font-size:1.5rem; font-weight:800; color:#10b981; margin-bottom:8px;">Instalasi Berhasil!</h3>
        <p style="color:#475569; font-size:0.95rem; margin-bottom:24px;">Database telah di-import dan file <code>config.php</code> telah diperbarui secara otomatis.</p>

        <div class="alert-success" style="text-align:left;">
          <strong>🔒 Catatan Keamanan:</strong> Demi keamanan web hosting Anda, sangat disarankan untuk menghapus file <code>install.php</code> dari server setelah instalasi selesai.
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-top:24px;">
          <a href="index.php" class="btn btn-outline" style="width:100%;">🌐 Buka Portal Publik</a>
          <a href="admin.php" class="btn btn-primary" style="width:100%;">🔒 Buka Portal Admin</a>
        </div>
      </div>
    <?php endif; ?>

  </div>

</body>
</html>
