<?php
/**
 * REST API Backend untuk SI BANSOS Kabupaten Bireuen
 * Menyediakan JSON response untuk pencarian, statistik, CRUD Admin (Penerima & Program Bansos), Usulan, & Pengaduan.
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . '/config.php';

$pdo = getDBConnection();
$action = isset($_GET['action']) ? trim($_GET['action']) : '';

if (!$pdo) {
    if ($action === 'check_db') {
        echo json_encode(['status' => 'offline', 'message' => 'Database MySQL belum terkoneksi. Menggunakan Mode Standalone JS Storage.']);
        exit();
    }
    echo json_encode([
        'status' => 'offline',
        'message' => 'Koneksi database MySQL offline. Silakan import database.sql dan sesuaikan config.php'
    ]);
    exit();
}

switch ($action) {
    case 'check_db':
        echo json_encode(['status' => 'online', 'message' => 'Koneksi database MySQL berhasil!']);
        break;

    // -------------------------------------------------------------
    // 1. CEK BANSOS PUBLIC SEARCH
    // -------------------------------------------------------------
    case 'search_bansos':
        $query = isset($_GET['q']) ? trim($_GET['q']) : '';
        $kecamatan = isset($_GET['kecamatan']) ? trim($_GET['kecamatan']) : '';

        if (empty($query) && empty($kecamatan)) {
            echo json_encode(['status' => 'error', 'message' => 'Masukkan NIK, Nama, atau pilih Kecamatan.']);
            exit();
        }

        try {
            $sql = "SELECT id, CONCAT(SUBSTR(nik,1,6), '********', SUBSTR(nik,15,2)) AS nik_masked, nik, 
                           nama_lengkap, jenis_kelamin, gampong, kecamatan, program_diterima, 
                           status_verifikasi, status_penyaluran, tanggal_penyaluran_terakhir, keterangan 
                    FROM penerima_bansos WHERE 1=1";
            $params = [];

            if (!empty($query)) {
                $sql .= " AND (nik LIKE :q OR nama_lengkap LIKE :q OR gampong LIKE :q)";
                $params['q'] = '%' . $query . '%';
            }

            if (!empty($kecamatan)) {
                $sql .= " AND kecamatan = :kecamatan";
                $params['kecamatan'] = $kecamatan;
            }

            $sql .= " ORDER BY id DESC LIMIT 50";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $data = $stmt->fetchAll();

            echo json_encode([
                'status' => 'success',
                'count' => count($data),
                'data' => $data
            ]);
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    // -------------------------------------------------------------
    // 2. DASHBOARD STATISTIK
    // -------------------------------------------------------------
    case 'get_stats':
        try {
            $total_penerima = $pdo->query("SELECT COUNT(*) FROM penerima_bansos")->fetchColumn();
            $total_terverifikasi = $pdo->query("SELECT COUNT(*) FROM penerima_bansos WHERE status_verifikasi = 'Terverifikasi'")->fetchColumn();
            $total_tersalurkan = $pdo->query("SELECT COUNT(*) FROM penerima_bansos WHERE status_penyaluran = 'Tersalurkan'")->fetchColumn();
            $total_usulan = $pdo->query("SELECT COUNT(*) FROM usulan_bansos")->fetchColumn();
            $total_pengaduan = $pdo->query("SELECT COUNT(*) FROM pengaduan")->fetchColumn();

            $program_stats = $pdo->query("SELECT program_diterima, COUNT(*) as total FROM penerima_bansos GROUP BY program_diterima")->fetchAll();
            $kecamatan_stats = $pdo->query("SELECT kecamatan, COUNT(*) as total FROM penerima_bansos GROUP BY kecamatan ORDER BY total DESC")->fetchAll();

            echo json_encode([
                'status' => 'success',
                'summary' => [
                    'total_penerima' => (int)$total_penerima,
                    'total_terverifikasi' => (int)$total_terverifikasi,
                    'total_tersalurkan' => (int)$total_tersalurkan,
                    'total_usulan' => (int)$total_usulan,
                    'total_pengaduan' => (int)$total_pengaduan
                ],
                'program_stats' => $program_stats,
                'kecamatan_stats' => $kecamatan_stats
            ]);
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    // -------------------------------------------------------------
    // 3. GET LIST PENERIMA BANSOS (ADMIN)
    // -------------------------------------------------------------
    case 'list_penerima':
        try {
            $kecamatan = isset($_GET['kecamatan']) ? trim($_GET['kecamatan']) : '';
            $program = isset($_GET['program']) ? trim($_GET['program']) : '';
            $search = isset($_GET['search']) ? trim($_GET['search']) : '';

            $sql = "SELECT * FROM penerima_bansos WHERE 1=1";
            $params = [];

            if (!empty($kecamatan)) {
                $sql .= " AND kecamatan = :kecamatan";
                $params['kecamatan'] = $kecamatan;
            }
            if (!empty($program)) {
                $sql .= " AND program_diterima = :program";
                $params['program'] = $program;
            }
            if (!empty($search)) {
                $sql .= " AND (nik LIKE :search OR nama_lengkap LIKE :search OR gampong LIKE :search)";
                $params['search'] = '%' . $search . '%';
            }

            $sql .= " ORDER BY id DESC LIMIT 100";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $data = $stmt->fetchAll();

            echo json_encode(['status' => 'success', 'data' => $data]);
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    // -------------------------------------------------------------
    // 4. KELOLA PROGRAM BANSOS (CRUD PROGRAM)
    // -------------------------------------------------------------
    case 'list_program':
        try {
            $stmt = $pdo->query("SELECT * FROM program_bansos ORDER BY id ASC");
            $data = $stmt->fetchAll();
            echo json_encode(['status' => 'success', 'data' => $data]);
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    case 'add_program':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['status' => 'error', 'message' => 'Metode request tidak diizinkan.']);
            exit();
        }
        $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

        $kode = strtoupper(trim($input['kode_program'] ?? ''));
        $nama = trim($input['nama_program'] ?? '');
        $deskripsi = trim($input['deskripsi'] ?? '');
        $penyelenggara = trim($input['penyelenggara'] ?? 'Dinas Sosial / Kemensos');
        $nominal = trim($input['nominal_bantuan'] ?? '');
        $periode = trim($input['periode'] ?? '');
        $kuota = (int)($input['kuota_nasional_daerah'] ?? 0);
        $status = trim($input['status'] ?? 'Aktif');

        if (empty($kode) || empty($nama)) {
            echo json_encode(['status' => 'error', 'message' => 'Kode dan Nama Program wajib diisi.']);
            exit();
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO program_bansos (kode_program, nama_program, deskripsi, penyelenggara, nominal_bantuan, periode, kuota_nasional_daerah, status) VALUES (:kode, :nama, :deskripsi, :penyelenggara, :nominal, :periode, :kuota, :status)");
            $stmt->execute([
                'kode' => $kode,
                'nama' => $nama,
                'deskripsi' => $deskripsi,
                'penyelenggara' => $penyelenggara,
                'nominal' => $nominal,
                'periode' => $periode,
                'kuota' => $kuota,
                'status' => $status
            ]);
            echo json_encode(['status' => 'success', 'message' => 'Program Bantuan Sosial berhasil ditambahkan!']);
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    case 'toggle_program':
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($id <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'ID tidak valid.']);
            exit();
        }
        try {
            $stmt = $pdo->prepare("UPDATE program_bansos SET status = IF(status='Aktif','Non-Aktif','Aktif') WHERE id = :id");
            $stmt->execute(['id' => $id]);
            echo json_encode(['status' => 'success', 'message' => 'Status program berhasil diperbarui.']);
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    case 'delete_program':
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($id <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'ID tidak valid.']);
            exit();
        }
        try {
            $stmt = $pdo->prepare("DELETE FROM program_bansos WHERE id = :id");
            $stmt->execute(['id' => $id]);
            echo json_encode(['status' => 'success', 'message' => 'Program berhasil dihapus.']);
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    // -------------------------------------------------------------
    // 5. SUBMIT USULAN MANDIRI (CITIZEN)
    // -------------------------------------------------------------
    case 'submit_usulan':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['status' => 'error', 'message' => 'Metode request tidak diizinkan.']);
            exit();
        }
        $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

        $nik = trim($input['nik'] ?? '');
        $nama = trim($input['nama'] ?? '');
        $hp = trim($input['hp'] ?? '');
        $kecamatan = trim($input['kecamatan'] ?? '');
        $gampong = trim($input['gampong'] ?? '');
        $alamat = trim($input['alamat'] ?? '');
        $program = trim($input['program'] ?? '');
        $alasan = trim($input['alasan'] ?? '');

        if (empty($nik) || empty($nama) || empty($kecamatan) || empty($gampong) || empty($program)) {
            echo json_encode(['status' => 'error', 'message' => 'Lengkapi data wajib pengajuan usulan.']);
            exit();
        }

        try {
            $no_usulan = 'USL-' . date('Ym') . '-' . rand(100, 999);
            $stmt = $pdo->prepare("INSERT INTO usulan_bansos (no_usulan, nik, nama_pengusul, no_hp, kecamatan, gampong, alamat_lengkap, program_diusulkan, alasan_pengajuan) VALUES (:no_usulan, :nik, :nama, :hp, :kecamatan, :gampong, :alamat, :program, :alasan)");
            $stmt->execute([
                'no_usulan' => $no_usulan,
                'nik' => $nik,
                'nama' => $nama,
                'hp' => $hp,
                'kecamatan' => $kecamatan,
                'gampong' => $gampong,
                'alamat' => $alamat,
                'program' => $program,
                'alasan' => $alasan
            ]);

            echo json_encode([
                'status' => 'success',
                'message' => 'Usulan bansos berhasil dikirim!',
                'no_usulan' => $no_usulan
            ]);
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    // -------------------------------------------------------------
    // 6. SUBMIT PENGADUAN (LAPOR BANSOS)
    // -------------------------------------------------------------
    case 'submit_pengaduan':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['status' => 'error', 'message' => 'Metode request tidak diizinkan.']);
            exit();
        }
        $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

        $nama = trim($input['nama'] ?? '');
        $email_hp = trim($input['email_hp'] ?? '');
        $kategori = trim($input['kategori'] ?? '');
        $kecamatan = trim($input['kecamatan'] ?? '');
        $isi = trim($input['isi'] ?? '');

        if (empty($nama) || empty($email_hp) || empty($kategori) || empty($isi)) {
            echo json_encode(['status' => 'error', 'message' => 'Lengkapi form pengaduan.']);
            exit();
        }

        try {
            $ticket_id = 'TCK-' . rand(10000, 99999);
            $stmt = $pdo->prepare("INSERT INTO pengaduan (ticket_id, nama_pelapor, email_hp, kategori, kecamatan, isi_laporan) VALUES (:ticket_id, :nama, :email_hp, :kategori, :kecamatan, :isi)");
            $stmt->execute([
                'ticket_id' => $ticket_id,
                'nama' => $nama,
                'email_hp' => $email_hp,
                'kategori' => $kategori,
                'kecamatan' => $kecamatan,
                'isi' => $isi
            ]);

            echo json_encode([
                'status' => 'success',
                'message' => 'Laporan pengaduan berhasil dikirim!',
                'ticket_id' => $ticket_id
            ]);
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    // -------------------------------------------------------------
    // 7. ADD PENERIMA BARU (ADMIN)
    // -------------------------------------------------------------
    case 'add_penerima':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['status' => 'error', 'message' => 'Metode tidak valid.']);
            exit();
        }
        $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

        try {
            $stmt = $pdo->prepare("INSERT INTO penerima_bansos (nik, nkk, nama_lengkap, jenis_kelamin, alamat, gampong, kecamatan, pekerjaan, penghasilan_bulanan, jumlah_tanggungan, program_diterima, status_verifikasi, status_penyaluran, keterangan) VALUES (:nik, :nkk, :nama, :jk, :alamat, :gampong, :kecamatan, :pekerjaan, :penghasilan, :tanggungan, :program, :verifikasi, :penyaluran, :keterangan)");
            $stmt->execute([
                'nik' => $input['nik'],
                'nkk' => $input['nkk'],
                'nama' => $input['nama_lengkap'],
                'jk' => $input['jenis_kelamin'],
                'alamat' => $input['alamat'],
                'gampong' => $input['gampong'],
                'kecamatan' => $input['kecamatan'],
                'pekerjaan' => $input['pekerjaan'] ?? 'Buruh',
                'penghasilan' => (int)($input['penghasilan_bulanan'] ?? 0),
                'tanggungan' => (int)($input['jumlah_tanggungan'] ?? 1),
                'program' => $input['program_diterima'],
                'verifikasi' => $input['status_verifikasi'] ?? 'Terverifikasi',
                'penyaluran' => $input['status_penyaluran'] ?? 'Tersalurkan',
                'keterangan' => $input['keterangan'] ?? ''
            ]);

            echo json_encode(['status' => 'success', 'message' => 'Data penerima berhasil ditambahkan.']);
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    // -------------------------------------------------------------
    // 8. DELETE PENERIMA (ADMIN)
    // -------------------------------------------------------------
    case 'delete_penerima':
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($id <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'ID tidak valid.']);
            exit();
        }
        try {
            $stmt = $pdo->prepare("DELETE FROM penerima_bansos WHERE id = :id");
            $stmt->execute(['id' => $id]);
            echo json_encode(['status' => 'success', 'message' => 'Data berhasil dihapus.']);
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    default:
        echo json_encode(['status' => 'error', 'message' => 'Action tidak dikenali.']);
        break;
}
?>
