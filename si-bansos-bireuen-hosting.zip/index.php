<?php
require_once __DIR__ . '/config.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SI-BANSOS | Sistem Informasi Bantuan Sosial Kabupaten Bireuen</title>
  <meta name="description" content="Portal Resmi Sistem Informasi Data Terpadu Kesejahteraan Sosial (DTKS) & Penyaluran Bantuan Sosial Kabupaten Bireuen, Provinsi Aceh.">
  <link rel="stylesheet" href="assets/css/style.css">
  <!-- Chart.js CDN for statistics -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

  <!-- Top Bar -->
  <div class="top-bar">
    <div class="container">
      <div class="top-bar-info">
        <span>📍 Dinas Sosial Kabupaten Bireuen, Provinsi Aceh</span>
        <span>📞 Layanan Posko Bansos: (0644) 321-456</span>
      </div>
      <div>
        <span>🕒 Jam Layanan: Senin - Jumat (08.00 - 16.30 WIB)</span>
      </div>
    </div>
  </div>

  <!-- Navbar -->
  <nav class="navbar">
    <div class="container">
      <a href="index.php" class="brand">
        <div class="brand-emblem">SB</div>
        <div class="brand-text">
          <h1>SI-BANSOS</h1>
          <span>Kabupaten Bireuen</span>
        </div>
      </a>
      <ul class="nav-links">
        <li><a href="#beranda" class="active">Beranda</a></li>
        <li><a href="#cek-bansos">Cek Bansos</a></li>
        <li><a href="#program">Program Bansos</a></li>
        <li><a href="#usulan">Pengajuan Usulan</a></li>
        <li><a href="#pengaduan">Lapor / Pengaduan</a></li>
        <li><a href="admin.php" class="btn btn-primary btn-sm">🔒 Portal Admin</a></li>
      </ul>
    </div>
  </nav>

  <!-- Hero Section -->
  <section class="hero" id="beranda">
    <div class="container">
      <div class="hero-grid">
        <div>
          <div class="hero-badge">
            <span>🛡️ Portal Resmi Dinas Sosial Kabupaten Bireuen</span>
          </div>
          <h2 class="hero-title">Transparansi & Kemudahan <span>Cek Data Bantuan Sosial</span></h2>
          <p class="hero-desc">
            Sistem terpadu pengecekan penerima Bantuan Sosial (PKH, BPNT, BLT-DD, Bansos Pangan) secara transparan, akurat, dan dapat diakses langsung oleh seluruh warga masyarakat Kabupaten Bireuen.
          </p>
          <div style="display:flex; gap:16px; flex-wrap:wrap;">
            <a href="#cek-bansos" class="btn btn-primary">🔍 Cek Bansos Sekarang</a>
            <a href="#usulan" class="btn btn-outline" style="color:white; border-color:rgba(255,255,255,0.4);">📝 Form Usulan Mandiri</a>
          </div>
        </div>

        <!-- Card Search -->
        <div class="search-card" id="cek-bansos">
          <h3>🔍 Cek Penerima Bansos</h3>
          <p>Cari berdasarkan NIK KTP atau Nama Penerima Manfaat (KPM)</p>
          <form id="form-cek-bansos">
            <div class="form-group">
              <label class="form-label" for="search-query">NIK KTP atau Nama Lengkap</label>
              <input type="text" id="search-query" class="form-control" placeholder="Contoh: 1111011504820001 atau Iskandar">
            </div>
            <div class="form-group">
              <label class="form-label" for="search-kecamatan">Pilih Kecamatan (Opsional)</label>
              <select id="search-kecamatan" class="form-control">
                <option value="">-- Semua Kecamatan di Bireuen --</option>
                <option value="Kota Juang">Kota Juang</option>
                <option value="Peusangan">Peusangan</option>
                <option value="Samalanga">Samalanga</option>
                <option value="Gandapura">Gandapura</option>
                <option value="Juli">Juli</option>
                <option value="Peudada">Peudada</option>
                <option value="Jeunieb">Jeunieb</option>
                <option value="Pandrah">Pandrah</option>
                <option value="Makmur">Makmur</option>
                <option value="Kuta Blang">Kuta Blang</option>
              </select>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;">Cari Data Penerima</button>
          </form>
        </div>
      </div>
      
      <div id="search-results"></div>
    </div>
  </section>

  <!-- Summary Stats -->
  <section class="section" style="padding-top:0;">
    <div class="container">
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon green">👥</div>
          <div class="stat-info">
            <h4>86.250</h4>
            <p>Total KPM Terdaftar DTKS</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon amber">💳</div>
          <div class="stat-info">
            <h4>Rp 42,5 M</h4>
            <p>Anggaran Bansos Tersalurkan</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon blue">🏛️</div>
          <div class="stat-info">
            <h4>17</h4>
            <p>Kecamatan Terjangkau</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon green">✅</div>
          <div class="stat-info">
            <h4>98,4%</h4>
            <p>Tingkat Realisasi Salur</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Program Bansos Section -->
  <section class="section" id="program" style="background:#f1f5f9;">
    <div class="container">
      <div class="section-header">
        <div class="section-subtitle">Jenis Bantuan</div>
        <h2 class="section-title">Program Bantuan Sosial Utama</h2>
        <p class="section-desc">Ketahui berbagai program bantuan sosial pemerintah yang disalurkan bagi masyarakat Kabupaten Bireuen.</p>
      </div>

      <div class="program-grid">
        <div class="program-card">
          <div>
            <span class="program-tag">Kemensos RI</span>
            <h4>Program Keluarga Harapan (PKH)</h4>
            <p>Bantuan sosial bersyarat kepada Keluarga Miskin (KM) untuk akses kesehatan, pendidikan, dan kesejahteraan sosial.</p>
          </div>
          <div class="program-meta">
            <span>Nominal: s/d Rp 750rb/Tahap</span>
            <span>4 Tahap / Thn</span>
          </div>
        </div>

        <div class="program-card">
          <div>
            <span class="program-tag">Sembako</span>
            <h4>Bantuan Pangan Non-Tunai (BPNT)</h4>
            <p>Bantuan dalam bentuk saldo elektronik / uang tunai via Bank BSI untuk pemenuhan kebutuhan bahan pokok harian.</p>
          </div>
          <div class="program-meta">
            <span>Nominal: Rp 200rb/Bulan</span>
            <span>Setiap Bulan</span>
          </div>
        </div>

        <div class="program-card">
          <div>
            <span class="program-tag">Dana Desa</span>
            <h4>BLT Dana Desa (BLT-DD)</h4>
            <p>Pemberian uang tunai bagi keluarga miskin di setiap Gampong/Desa bersumber dari alokasi Dana Desa.</p>
          </div>
          <div class="program-meta">
            <span>Nominal: Rp 300rb/Bulan</span>
            <span>Tingkat Gampong</span>
          </div>
        </div>

        <div class="program-card">
          <div>
            <span class="program-tag">Cadangan Pangan</span>
            <h4>Bansos Beras 10 KG</h4>
            <p>Bantuan pangan cadangan beras pemerintah untuk menjaga stabilitas harga dan ketahanan pangan rumah tangga.</p>
          </div>
          <div class="program-meta">
            <span>Paket: 10 Kg Beras</span>
            <span>Bulanan</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Form Usulan Mandiri -->
  <section class="section" id="usulan">
    <div class="container">
      <div class="section-header">
        <div class="section-subtitle">Layanan Publik</div>
        <h2 class="section-title">Formulir Usulan Mandiri Bansos</h2>
        <p class="section-desc">Masyarakat atau anggota keluarga kurang mampu yang belum terdaftar dapat mengajukan usulan mandiri untuk dikaji oleh Dinas Sosial.</p>
      </div>

      <div style="max-width:760px; margin:0 auto; background:white; padding:36px; border-radius:18px; border:1px solid #e2e8f0; box-shadow:var(--shadow-md);">
        <form id="form-usulan">
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
            <div class="form-group">
              <label class="form-label" for="usulan-nik">NIK KTP (16 Digit)</label>
              <input type="text" id="usulan-nik" class="form-control" placeholder="111101xxxxxxxxxx" maxlength="16" required>
            </div>
            <div class="form-group">
              <label class="form-label" for="usulan-nama">Nama Lengkap Sesuai KTP</label>
              <input type="text" id="usulan-nama" class="form-control" placeholder="Nama Lengkap" required>
            </div>
          </div>

          <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
            <div class="form-group">
              <label class="form-label" for="usulan-hp">No. Handphone / WhatsApp</label>
              <input type="tel" id="usulan-hp" class="form-control" placeholder="0852xxxxxxxx" required>
            </div>
            <div class="form-group">
              <label class="form-label" for="usulan-program">Program yang Diusulkan</label>
              <select id="usulan-program" class="form-control" required>
                <option value="PKH">Program Keluarga Harapan (PKH)</option>
                <option value="BPNT">BPNT / Sembako</option>
                <option value="BLT-DD">BLT Dana Desa</option>
                <option value="BANSOS-PANGAN">Bansos Cadangan Pangan</option>
              </select>
            </div>
          </div>

          <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
            <div class="form-group">
              <label class="form-label" for="usulan-kecamatan">Kecamatan</label>
              <select id="usulan-kecamatan" class="form-control" required>
                <option value="Kota Juang">Kota Juang</option>
                <option value="Peusangan">Peusangan</option>
                <option value="Samalanga">Samalanga</option>
                <option value="Gandapura">Gandapura</option>
                <option value="Juli">Juli</option>
                <option value="Peudada">Peudada</option>
                <option value="Jeunieb">Jeunieb</option>
                <option value="Pandrah">Pandrah</option>
                <option value="Makmur">Makmur</option>
                <option value="Kuta Blang">Kuta Blang</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label" for="usulan-gampong">Nama Gampong / Desa</label>
              <input type="text" id="usulan-gampong" class="form-control" placeholder="Contoh: Gampong Kota Bireuen" required>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label" for="usulan-alamat">Alamat Lengkap (Dusun / Jalan / No. Rumah)</label>
            <input type="text" id="usulan-alamat" class="form-control" placeholder="Alamat tempat tinggal saat ini" required>
          </div>

          <div class="form-group">
            <label class="form-label" for="usulan-alasan">Alasan Pengajuan / Kondisi Ekonomi</label>
            <textarea id="usulan-alasan" class="form-control" rows="3" placeholder="Jelaskan kondisi ekonomi, pekerjaan, dan tanggungan keluarga..." required></textarea>
          </div>

          <button type="submit" class="btn btn-primary" style="width:100%;">Kirim Pengajuan Usulan</button>
        </form>
      </div>
    </div>
  </section>

  <!-- Lapor / Pengaduan -->
  <section class="section" id="pengaduan" style="background:#f8fafc;">
    <div class="container">
      <div class="section-header">
        <div class="section-subtitle">Layanan Pengaduan</div>
        <h2 class="section-title">Posko Lapor Bansos Bireuen</h2>
        <p class="section-desc">Laporkan jika ada indikasi pungli, pemotongan dana, masalah rekening, atau ketidaktepatan sasaran bantuan.</p>
      </div>

      <div style="max-width:760px; margin:0 auto; background:white; padding:36px; border-radius:18px; border:1px solid #e2e8f0;">
        <form id="form-pengaduan">
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
            <div class="form-group">
              <label class="form-label" for="pengaduan-nama">Nama Pelapor</label>
              <input type="text" id="pengaduan-nama" class="form-control" placeholder="Nama Anda" required>
            </div>
            <div class="form-group">
              <label class="form-label" for="pengaduan-kontak">Email atau No. WhatsApp</label>
              <input type="text" id="pengaduan-kontak" class="form-control" placeholder="08xxxx / email@domain.com" required>
            </div>
          </div>

          <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
            <div class="form-group">
              <label class="form-label" for="pengaduan-kategori">Kategori Laporan</label>
              <select id="pengaduan-kategori" class="form-control" required>
                <option value="Bantuan Belum Cair">Bantuan Belum Cair / Saldo Nol</option>
                <option value="Pungli / Pemotongan">Pungli / Pemotongan Bantuan</option>
                <option value="Salah Sasaran">Penerima Tidak Layak (Salah Sasaran)</option>
                <option value="Data Tidak Sesuai">Data KTP / KK Tidak Sesuai</option>
                <option value="Lainnya">Lain-Lain</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label" for="pengaduan-kecamatan">Kecamatan Kejadian</label>
              <select id="pengaduan-kecamatan" class="form-control" required>
                <option value="Kota Juang">Kota Juang</option>
                <option value="Peusangan">Peusangan</option>
                <option value="Samalanga">Samalanga</option>
                <option value="Gandapura">Gandapura</option>
                <option value="Juli">Juli</option>
                <option value="Peudada">Peudada</option>
                <option value="Jeunieb">Jeunieb</option>
                <option value="Pandrah">Pandrah</option>
                <option value="Makmur">Makmur</option>
                <option value="Kuta Blang">Kuta Blang</option>
              </select>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label" for="pengaduan-isi">Rincian Laporan Pengaduan</label>
            <textarea id="pengaduan-isi" class="form-control" rows="4" placeholder="Tulis rincian lokasi gampong, kronologi kejadian, dan informasi terkait..." required></textarea>
          </div>

          <button type="submit" class="btn btn-amber" style="width:100%;">Kirim Pengaduan</button>
        </form>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <h3>SI-BANSOS Kabupaten Bireuen</h3>
          <p>Sistem Informasi Data Terpadu Kesejahteraan Sosial & Penyaluran Bantuan Sosial Pemerintah Kabupaten Bireuen, Aceh.</p>
          <p style="margin-top:10px; font-size:0.85rem; color:#94a3b8;">Alamat Kantor: Jl. T. Hamzah Bendahara No. 1, Kota Bireuen, Aceh</p>
        </div>
        <div>
          <h4 style="color:white; margin-bottom:14px;">Navigasi Cepat</h4>
          <p><a href="#cek-bansos" style="color:#cbd5e1;">Cek Data Bansos</a></p>
          <p><a href="#program" style="color:#cbd5e1;">Program Bantuan</a></p>
          <p><a href="#usulan" style="color:#cbd5e1;">Form Usulan</a></p>
          <p><a href="#pengaduan" style="color:#cbd5e1;">Posko Lapor</a></p>
        </div>
        <div>
          <h4 style="color:white; margin-bottom:14px;">Kontak Darurat</h4>
          <p style="color:#cbd5e1;">Call Center: 1500-299</p>
          <p style="color:#cbd5e1;">WhatsApp: 0852-6000-8899</p>
          <p style="color:#cbd5e1;">Email: dinsos@bireuenkab.go.id</p>
        </div>
      </div>
      <div class="footer-bottom">
        <p>© 2026 Pemerintah Kabupaten Bireuen. Hak Cipta Dilindungi Undang-Undang.</p>
        <p>Powered by Dinas Sosial Bireuen - Ready for Web Hosting</p>
      </div>
    </div>
  </footer>

  <script src="assets/js/main.js"></script>
</body>
</html>
