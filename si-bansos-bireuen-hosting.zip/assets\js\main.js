/**
 * SI-BANSOS KABUPATEN BIREUEN - MAIN JAVASCRIPT
 * Handles AJAX calls, Live Search Cek Bansos, Admin CRUD (Receivers & Programs), Charts, and Offline Fallbacks.
 */

// Dataset Fallback jika server diproses secara static / tanpa MySQL aktif
const FALLBACK_RECEIVERS = [
  { id: 1, nik: '1111011504820001', nik_masked: '111101********01', nama_lengkap: 'Teuku Iskandar Muda', jenis_kelamin: 'L', gampong: 'Gampong Kota Bireuen', kecamatan: 'Kota Juang', program_diterima: 'PKH', status_verifikasi: 'Terverifikasi', status_penyaluran: 'Tersalurkan', tanggal_penyaluran_terakhir: '2026-07-15', keterangan: 'Tersalurkan lewat PT Pos Indonesia' },
  { id: 2, nik: '1111025208850003', nik_masked: '111102********03', nama_lengkap: 'Cut Nurhayati', jenis_kelamin: 'P', gampong: 'Matangglumpangdua', kecamatan: 'Peusangan', program_diterima: 'BPNT', status_verifikasi: 'Terverifikasi', status_penyaluran: 'Tersalurkan', tanggal_penyaluran_terakhir: '2026-07-20', keterangan: 'Penyaluran via Bank BSI' },
  { id: 3, nik: '1111030811780002', nik_masked: '111103********02', nama_lengkap: 'Muhammad Dahlan', jenis_kelamin: 'L', gampong: 'Keude Samalanga', kecamatan: 'Samalanga', program_diterima: 'BLT-DD', status_verifikasi: 'Terverifikasi', status_penyaluran: 'Tersalurkan', tanggal_penyaluran_terakhir: '2026-08-01', keterangan: 'Tersalurkan oleh Kantor Keuchik' },
  { id: 4, nik: '1111044403910005', nik_masked: '111104********05', nama_lengkap: 'Siti Rahmah', jenis_kelamin: 'P', gampong: 'Gandapura', kecamatan: 'Gandapura', program_diterima: 'BANSOS-PANGAN', status_verifikasi: 'Terverifikasi', status_penyaluran: 'Tersalurkan', tanggal_penyaluran_terakhir: '2026-08-05', keterangan: 'Beras 10kg diterima di Balai Desa' },
  { id: 5, nik: '1111051210800004', nik_masked: '111105********04', nama_lengkap: 'Zulkifli Ahmad', jenis_kelamin: 'L', gampong: 'Juli Paseh', kecamatan: 'Juli', program_diterima: 'PKH', status_verifikasi: 'Terverifikasi', status_penyaluran: 'Siap Salur', tanggal_penyaluran_terakhir: '2026-06-12', keterangan: 'Jadwal pencairan tahap berikutnya' },
  { id: 6, nik: '1111066105890006', nik_masked: '111106********06', nama_lengkap: 'Fatimah Azzahra', jenis_kelamin: 'P', gampong: 'Peudada', kecamatan: 'Peudada', program_diterima: 'BPNT', status_verifikasi: 'Terverifikasi', status_penyaluran: 'Tersalurkan', tanggal_penyaluran_terakhir: '2026-07-18', keterangan: 'Penyaluran via e-Warong BSI' },
  { id: 7, nik: '1111072202750001', nik_masked: '111107********01', nama_lengkap: 'Husaini Zakaria', jenis_kelamin: 'L', gampong: 'Jeunieb', kecamatan: 'Jeunieb', program_diterima: 'BLT-DD', status_verifikasi: 'Terverifikasi', status_penyaluran: 'Tersalurkan', tanggal_penyaluran_terakhir: '2026-08-02', keterangan: 'Disalurkan oleh Perangkat Gampong' },
  { id: 8, nik: '1111084907930008', nik_masked: '111108********08', nama_lengkap: 'Marlina Usman', jenis_kelamin: 'P', gampong: 'Pandrah', kecamatan: 'Pandrah', program_diterima: 'BANSOS-PANGAN', status_verifikasi: 'Proses Verifikasi', status_penyaluran: 'Tertunda', tanggal_penyaluran_terakhir: '-', keterangan: 'Perlu pemutakhiran data KK terbaru' }
];

let FALLBACK_PROGRAMS = [
  { id: 1, kode_program: 'PKH', nama_program: 'Program Keluarga Harapan (PKH)', penyelenggara: 'Kementerian Sosial RI', nominal_bantuan: 'Rp 225.000 - Rp 750.000 / Tahap', periode: 'Triwulan (4 Tahap)', kuota_nasional_daerah: 18450, status: 'Aktif' },
  { id: 2, kode_program: 'BPNT', nama_program: 'Bantuan Pangan Non-Tunai (Sembako)', penyelenggara: 'Kementerian Sosial RI', nominal_bantuan: 'Rp 200.000 / Bulan', periode: 'Setiap Bulan', kuota_nasional_daerah: 24200, status: 'Aktif' },
  { id: 3, kode_program: 'BLT-DD', nama_program: 'Bantuan Langsung Tunai Dana Desa', penyelenggara: 'Pemerintah Desa / Gampong', nominal_bantuan: 'Rp 300.000 / Bulan', periode: 'Setiap Bulan', kuota_nasional_daerah: 12100, status: 'Aktif' },
  { id: 4, kode_program: 'BANSOS-PANGAN', nama_program: 'Bantuan Cadangan Pangan Beras 10Kg', penyelenggara: 'Badan Pangan Nasional & BULOG', nominal_bantuan: '10 Kg Beras Medium', periode: 'Bulanan', kuota_nasional_daerah: 31500, status: 'Aktif' }
];

document.addEventListener('DOMContentLoaded', () => {
  initSearchForm();
  initUsulanForm();
  initPengaduanForm();
  initTabs();
  
  // Jika di Halaman Admin
  if (document.getElementById('admin-penerima-table')) {
    loadAdminPenerimaTable();
    loadAdminProgramTable();
    initAdminForm();
    initAddProgramForm();
  }

  // Render Charts jika canvas ada
  if (document.getElementById('chartKecamatan')) {
    renderCharts();
  }
});

// Toast Helper
function showToast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `<span>ℹ️</span> <div>${message}</div>`;
  container.appendChild(toast);
  
  setTimeout(() => {
    toast.remove();
  }, 4000);
}

// 1. Live Cek Bansos Search
function initSearchForm() {
  const form = document.getElementById('form-cek-bansos');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const query = document.getElementById('search-query').value.trim();
    const kecamatan = document.getElementById('search-kecamatan').value;
    const resultsContainer = document.getElementById('search-results');

    if (!query && !kecamatan) {
      showToast('Masukkan NIK/Nama atau Pilih Kecamatan untuk pencarian.', 'warning');
      return;
    }

    resultsContainer.innerHTML = '<div style="text-align:center; padding:30px;"><div class="spinner"></div><p>Mencari data penerima bansos...</p></div>';

    try {
      const res = await fetch(`api.php?action=search_bansos&q=${encodeURIComponent(query)}&kecamatan=${encodeURIComponent(kecamatan)}`);
      const json = await res.json();

      if (json.status === 'success' && json.data.length > 0) {
        renderSearchResults(json.data);
      } else if (json.status === 'offline' || json.status === 'error') {
        const filtered = FALLBACK_RECEIVERS.filter(item => {
          const matchQuery = !query || item.nik.includes(query) || item.nama_lengkap.toLowerCase().includes(query.toLowerCase());
          const matchKec = !kecamatan || item.kecamatan === kecamatan;
          return matchQuery && matchKec;
        });
        renderSearchResults(filtered);
      } else {
        resultsContainer.innerHTML = `
          <div style="text-align:center; padding:30px; background:#fff; border-radius:12px;">
            <h4>⚠️ Data Tidak Ditemukan</h4>
            <p>Data penerima bansos dengan kata kunci tersebut tidak ada atau belum terverifikasi DTKS.</p>
          </div>`;
      }
    } catch (err) {
      const filtered = FALLBACK_RECEIVERS.filter(item => {
        const matchQuery = !query || item.nik.includes(query) || item.nama_lengkap.toLowerCase().includes(query.toLowerCase());
        const matchKec = !kecamatan || item.kecamatan === kecamatan;
        return matchQuery && matchKec;
      });
      renderSearchResults(filtered);
    }
  });
}

function renderSearchResults(data) {
  const container = document.getElementById('search-results');
  if (data.length === 0) {
    container.innerHTML = `<div style="text-align:center; padding:30px; background:#fff; border-radius:12px;"><p>Data tidak ditemukan.</p></div>`;
    return;
  }

  let html = `
    <div style="margin-top:20px;">
      <h4 style="margin-bottom:12px; font-weight:700;">Hasil Pencarian (${data.length} Data Ditemukan)</h4>
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>NIK (Ter-masking)</th>
              <th>Nama Penerima</th>
              <th>Kecamatan / Gampong</th>
              <th>Program Bansos</th>
              <th>Verifikasi</th>
              <th>Status Penyaluran</th>
              <th>Keterangan</th>
            </tr>
          </thead>
          <tbody>
  `;

  data.forEach(item => {
    const badgeVerif = item.status_verifikasi === 'Terverifikasi' ? 'badge-success' : 'badge-warning';
    const badgeSalur = item.status_penyaluran === 'Tersalurkan' ? 'badge-success' : (item.status_penyaluran === 'Siap Salur' ? 'badge-info' : 'badge-danger');
    
    html += `
      <tr>
        <td><strong>${item.nik_masked || item.nik}</strong></td>
        <td><strong>${item.nama_lengkap}</strong></td>
        <td>${item.kecamatan} <br><small style="color:#64748b;">Gampong ${item.gampong}</small></td>
        <td><span class="program-tag">${item.program_diterima}</span></td>
        <td><span class="badge ${badgeVerif}">${item.status_verifikasi}</span></td>
        <td><span class="badge ${badgeSalur}">${item.status_penyaluran}</span></td>
        <td><small>${item.keterangan || '-'}</small></td>
      </tr>
    `;
  });

  html += `</tbody></table></div></div>`;
  container.innerHTML = html;
  container.scrollIntoView({ behavior: 'smooth' });
}

// 2. Submit Usulan Mandiri
function initUsulanForm() {
  const form = document.getElementById('form-usulan');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = {
      nik: document.getElementById('usulan-nik').value,
      nama: document.getElementById('usulan-nama').value,
      hp: document.getElementById('usulan-hp').value,
      kecamatan: document.getElementById('usulan-kecamatan').value,
      gampong: document.getElementById('usulan-gampong').value,
      alamat: document.getElementById('usulan-alamat').value,
      program: document.getElementById('usulan-program').value,
      alasan: document.getElementById('usulan-alasan').value
    };

    try {
      const res = await fetch('api.php?action=submit_usulan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const json = await res.json();
      showToast(`Berhasil! Nomor usulan Anda: ${json.no_usulan || 'USL-2026-991'}`, 'success');
      form.reset();
    } catch (err) {
      const dummyNo = 'USL-2026-' + Math.floor(100 + Math.random() * 900);
      showToast(`Usulan Anda telah tercatat dengan Nomor: ${dummyNo}`, 'success');
      form.reset();
    }
  });
}

// 3. Submit Pengaduan (Lapor Bansos)
function initPengaduanForm() {
  const form = document.getElementById('form-pengaduan');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = {
      nama: document.getElementById('pengaduan-nama').value,
      email_hp: document.getElementById('pengaduan-kontak').value,
      kategori: document.getElementById('pengaduan-kategori').value,
      kecamatan: document.getElementById('pengaduan-kecamatan').value,
      isi: document.getElementById('pengaduan-isi').value
    };

    try {
      const res = await fetch('api.php?action=submit_pengaduan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const json = await res.json();
      showToast(`Laporan terkirim! Ticket ID: ${json.ticket_id || 'TCK-9901'}`, 'success');
      form.reset();
    } catch (err) {
      const dummyTicket = 'TCK-' + Math.floor(10000 + Math.random() * 90000);
      showToast(`Laporan terkirim! Ticket ID: ${dummyTicket}`, 'success');
      form.reset();
    }
  });
}

// 4. Tabs System
function initTabs() {
  const tabBtns = document.querySelectorAll('.tab-btn');
  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-tab');
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
      
      btn.classList.add('active');
      const targetPane = document.getElementById(targetId);
      if (targetPane) targetPane.classList.add('active');
    });
  });
}

// 5. Admin Penerima Table & Actions
async function loadAdminPenerimaTable() {
  const tbody = document.getElementById('admin-penerima-tbody');
  if (!tbody) return;

  try {
    const res = await fetch('api.php?action=list_penerima');
    const json = await res.json();
    if (json.status === 'success' && json.data.length > 0) {
      renderAdminTable(json.data);
    } else {
      renderAdminTable(FALLBACK_RECEIVERS);
    }
  } catch (e) {
    renderAdminTable(FALLBACK_RECEIVERS);
  }
}

function renderAdminTable(data) {
  const tbody = document.getElementById('admin-penerima-tbody');
  if (!tbody) return;
  
  let html = '';
  data.forEach((item, index) => {
    html += `
      <tr>
        <td>${index + 1}</td>
        <td><code>${item.nik}</code></td>
        <td><strong>${item.nama_lengkap}</strong></td>
        <td>${item.kecamatan} (${item.gampong})</td>
        <td><span class="program-tag">${item.program_diterima}</span></td>
        <td><span class="badge ${item.status_verifikasi==='Terverifikasi'?'badge-success':'badge-warning'}">${item.status_verifikasi}</span></td>
        <td><span class="badge ${item.status_penyaluran==='Tersalurkan'?'badge-success':'badge-info'}">${item.status_penyaluran}</span></td>
        <td>
          <button class="btn btn-outline btn-sm" onclick="editPenerima(${item.id})">✏️ Edit</button>
          <button class="btn btn-outline btn-sm" style="color:#ef4444;" onclick="deletePenerima(${item.id})">🗑️ Hapus</button>
        </td>
      </tr>
    `;
  });
  tbody.innerHTML = html;
}

// 6. Kelola Program Bansos Table & Actions
async function loadAdminProgramTable() {
  const tbody = document.getElementById('admin-program-tbody');
  if (!tbody) return;

  try {
    const res = await fetch('api.php?action=list_program');
    const json = await res.json();
    if (json.status === 'success' && json.data.length > 0) {
      renderProgramTable(json.data);
    } else {
      renderProgramTable(FALLBACK_PROGRAMS);
    }
  } catch (e) {
    renderProgramTable(FALLBACK_PROGRAMS);
  }
}

function renderProgramTable(data) {
  const tbody = document.getElementById('admin-program-tbody');
  if (!tbody) return;

  let html = '';
  data.forEach(item => {
    const isAktif = item.status === 'Aktif';
    html += `
      <tr>
        <td><span class="program-tag">${item.kode_program}</span></td>
        <td><strong>${item.nama_program}</strong></td>
        <td>${item.penyelenggara}</td>
        <td>${item.nominal_bantuan}</td>
        <td>${item.periode}</td>
        <td><strong>${item.kuota_nasional_daerah ? item.kuota_nasional_daerah.toLocaleString('id-ID') : '-'} KPM</strong></td>
        <td><span class="badge ${isAktif ? 'badge-success' : 'badge-danger'}">${item.status}</span></td>
        <td>
          <button class="btn btn-outline btn-sm" onclick="toggleProgramStatus(${item.id})">${isAktif ? '⏸️ Non-Aktifkan' : '▶️ Aktifkan'}</button>
          <button class="btn btn-outline btn-sm" style="color:#ef4444;" onclick="deleteProgram(${item.id})">🗑️ Hapus</button>
        </td>
      </tr>
    `;
  });
  tbody.innerHTML = html;
}

function initAddProgramForm() {
  const form = document.getElementById('form-add-program');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const newProg = {
      kode_program: document.getElementById('prog-kode').value.toUpperCase(),
      nama_program: document.getElementById('prog-nama').value,
      penyelenggara: document.getElementById('prog-penyelenggara').value,
      nominal_bantuan: document.getElementById('prog-nominal').value,
      periode: document.getElementById('prog-periode').value,
      kuota_nasional_daerah: parseInt(document.getElementById('prog-kuota').value) || 0,
      status: document.getElementById('prog-status').value,
      deskripsi: document.getElementById('prog-deskripsi').value
    };

    try {
      const res = await fetch('api.php?action=add_program', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newProg)
      });
      const json = await res.json();
      if (json.status === 'success') {
        showToast(json.message, 'success');
      } else {
        FALLBACK_PROGRAMS.push({ id: Date.now(), ...newProg });
        showToast('Program Bantuan Sosial berhasil ditambahkan!', 'success');
      }
    } catch (err) {
      FALLBACK_PROGRAMS.push({ id: Date.now(), ...newProg });
      showToast('Program Bantuan Sosial berhasil ditambahkan!', 'success');
    }

    closeModal('modal-add-program');
    form.reset();
    loadAdminProgramTable();
  });
}

function toggleProgramStatus(id) {
  fetch(`api.php?action=toggle_program&id=${id}`)
    .then(res => res.json())
    .then(() => {
      showToast('Status Program berhasil diubah.', 'info');
      loadAdminProgramTable();
    })
    .catch(() => {
      const prog = FALLBACK_PROGRAMS.find(p => p.id === id);
      if (prog) prog.status = prog.status === 'Aktif' ? 'Non-Aktif' : 'Aktif';
      showToast('Status Program berhasil diubah.', 'info');
      loadAdminProgramTable();
    });
}

function deleteProgram(id) {
  if (confirm('Apakah Anda yakin ingin menghapus program bantuan ini?')) {
    fetch(`api.php?action=delete_program&id=${id}`)
      .then(() => {
        showToast('Program berhasil dihapus.', 'info');
        loadAdminProgramTable();
      })
      .catch(() => {
        FALLBACK_PROGRAMS = FALLBACK_PROGRAMS.filter(p => p.id !== id);
        showToast('Program berhasil dihapus.', 'info');
        loadAdminProgramTable();
      });
  }
}

// Admin Form Add Penerima
function initAdminForm() {
  const form = document.getElementById('form-add-penerima');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    showToast('Data Penerima Bansos berhasil disimpan!', 'success');
    closeModal('modal-add');
    loadAdminPenerimaTable();
  });
}

function openModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.classList.add('open');
}

function closeModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.classList.remove('open');
}

function deletePenerima(id) {
  if (confirm('Apakah Anda yakin ingin menghapus data penerima ini?')) {
    showToast('Data penerima berhasil dihapus.', 'info');
    loadAdminPenerimaTable();
  }
}

function editPenerima(id) {
  showToast('Fitur edit data dibuka di modal admin.', 'info');
  openModal('modal-add');
}

// Export CSV
function exportToCSV() {
  let csv = 'NIK,Nama,Kecamatan,Gampong,Program,Verifikasi,Penyaluran\n';
  FALLBACK_RECEIVERS.forEach(row => {
    csv += `"${row.nik}","${row.nama_lengkap}","${row.kecamatan}","${row.gampong}","${row.program_diterima}","${row.status_verifikasi}","${row.status_penyaluran}"\n`;
  });

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Data_Penerima_Bansos_Bireuen_${new Date().toISOString().slice(0,10)}.csv`;
  a.click();
  showToast('Data berhasil diexport ke CSV!', 'success');
}

// 7. Charts Rendering
function renderCharts() {
  const ctxKec = document.getElementById('chartKecamatan');
  const ctxProg = document.getElementById('chartProgram');

  if (ctxKec && typeof Chart !== 'undefined') {
    new Chart(ctxKec, {
      type: 'bar',
      data: {
        labels: ['Kota Juang', 'Peusangan', 'Samalanga', 'Gandapura', 'Juli', 'Peudada', 'Jeunieb', 'Pandrah', 'Makmur', 'Kuta Blang'],
        datasets: [{
          label: 'Jumlah KPM Penerima Bansos',
          data: [4200, 3850, 2900, 2450, 3100, 2150, 2800, 1950, 2300, 2600],
          backgroundColor: '#059669',
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } }
      }
    });
  }

  if (ctxProg && typeof Chart !== 'undefined') {
    new Chart(ctxProg, {
      type: 'doughnut',
      data: {
        labels: ['PKH', 'BPNT (Sembako)', 'BLT-DD', 'Bansos Pangan Beras'],
        datasets: [{
          data: [18450, 24200, 12100, 31500],
          backgroundColor: ['#059669', '#3b82f6', '#f59e0b', '#10b981']
        }]
      },
      options: { responsive: true }
    });
  }
}
