# 🚀 Panduan Upload & Pemasangan Website SI-BANSOS di Web Hosting (cPanel / Shared Hosting / VPS)

Dokumen ini berisi panduan langkah demi langkah cara memasang website **Sistem Informasi Bantuan Sosial (SI-BANSOS) Kabupaten Bireuen** ke dalam web hosting Anda.

---

## 🛠️ Pemasangan Mudah Menggunakan Web Installer (`install.php`)

Website ini telah dilengkapi dengan **Web Installer Wizard** otomatis. Anda **tidak perlu** meng-import file SQL secara manual jika memilih metode ini.

### Langkah-Langkah:
1. Upload file [si-bansos-bireuen-hosting.zip](file:///c:/Users/User/Downloads/si-bansos-kabupaten-bireuen.4/si-bansos-bireuen-hosting.zip) ke **File Manager** cPanel di folder `public_html`, lalu klik **Extract**.
2. Buat database & user database MySQL di menu **cPanel -> MySQL Databases**.
3. Buka browser dan akses alamat website Anda: `https://domain-anda.com/install.php`
4. Masukkan **Nama Database**, **Username Database**, dan **Password Database**, lalu klik **Install Sekarang**.
5. Installer akan secara otomatis meng-import tabel, mengisi data awal Bireuen, dan memperbarui `config.php`!
6. Setelah selesai, hapus file `install.php` demi alasan keamanan.

---

## 📂 Struktur File Project
```
si-bansos-kabupaten-bireuen/
├── .htaccess                 # Konfigurasi keamanan & kompresi Gzip Apache
├── install.php               # Program Installer Otomatis (Web Installer Wizard)
├── config.php                # Pengaturan koneksi Database MySQL
├── database.sql              # Skrip skema database & data awal Kabupaten Bireuen
├── index.php                 # Halaman Portal Publik & Cek Bansos
├── admin.php                 # Halaman Dashboard Pengelolaan Admin (DTKS)
├── api.php                   # Backend REST API
├── assets/
│   ├── css/
│   │   └── style.css         # Stylesheet UI Modern (Glassmorphism & Responsive)
│   └── js/
│       └── main.js           # Logika Cek Bansos, AJAX, Charts, & CSV Export
└── README_HOSTING.md         # Panduan instalasi hosting (file ini)
```

---

## 🛠️ Metode Manual (Opsional)

Jika Anda lebih memilih metode instalasi manual:
1. Upload & Extract file project ke `public_html`.
2. Buka **phpMyAdmin** di cPanel, pilih database Anda, lalu klik **Import** dan pilih file `database.sql`.
3. Edit file `config.php` dan sesuaikan `DB_NAME`, `DB_USER`, dan `DB_PASS`.

---

## 🌐 Akses Website

- **Portal Publik Warga**: `https://domain-anda.com/`
- **Portal Admin & Operator**: `https://domain-anda.com/admin.php`
  - *Login Admin Default*: Username: `admin` | Password: `admin123`

---

*Dikembangkan untuk Pemerintah Kabupaten Bireuen, Provinsi Aceh.*
