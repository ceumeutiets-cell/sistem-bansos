@echo off
:: ============================================================
:: SI-BANSOS KABUPATEN BIREUEN - LOCALHOST LAUNCHER SCRIPT
:: Klik 2x file ini untuk menjalankan website di Localhost:8000
:: ============================================================

title SI-BANSOS Kabupaten Bireuen - Localhost Launcher
color 0A

echo ===================================================================
echo    SI-BANSOS KABUPATEN BIREUEN - PENGEMBANGAN LOCALHOST
echo ===================================================================
echo.
echo [1/2] Membuka browser ke http://localhost:8000 ...
start http://localhost:8000

echo [2/2] Menjalankan Server Lokal PHP di Port 8000...
echo.
echo Tekan [Ctrl + C] di jendela ini jika ingin menghentikan server.
echo ===================================================================
echo.

php -S localhost:8000

if %errorlevel% neq 0 (
    echo.
    echo -------------------------------------------------------------------
    echo [INFORMASI PHATH / SERVERS]
    echo Perintah 'php' tidak ditemukan di Environment Variables Windows Anda.
    echo.
    echo SOLUSI UNTUK MENJALANKAN DI LOCALHOST:
    echo 1. Jika menggunakan XAMPP: Copy folder ini ke `C:\xampp\htdocs\` 
    echo    lalu buka browser: http://localhost/si-bansos-kabupaten-bireuen.4
    echo 2. Jika menggunakan Laragon: Copy folder ini ke `C:\laragon\www\`
    echo 3. Atau buka file `index.php` / `install.php` langsung di Web Hosting.
    echo -------------------------------------------------------------------
    echo.
    pause
)
