<?php
require_once __DIR__ . '/config.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Admin | SI-BANSOS Kabupaten Bireuen</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body style="background:#f8fafc;">

  <!-- Admin Top Bar -->
  <div style="background:var(--neutral-900); color:white; padding:12px 0; border-bottom:1px solid rgba(255,255,255,0.1);">
    <div class="container" style="display:flex; justify-content:space-between; align-items:center;">
      <div style="display:flex; align-items:center; gap:12px;">
        <span style="background:var(--primary-600); font-weight:800; padding:4px 10px; border-radius:6px; font-size:0.8rem;">ADMIN PORTAL</span>
        <strong style="font-size:1rem;">Dinas Sosial Kabupaten Bireuen</strong>
      </div>
      <div style="display:flex; align-items:center; gap:16px;">
        <span style="font-size:0.875rem; color:#cbd5e1;">👤 Operator: Administrator Dinsos</span>
        <a href="index.php" class="btn btn-outline btn-sm" style="color:white; border-color:rgba(255,255,255,0.3);">🌐 Lihat Portal Publik</a>
      </div>
    </div>
  </div>

  <div class="container" style="margin-top:30px; margin-bottom:60px;">
    
    <!-- Header Title & Action Buttons -->
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; flex-wrap:wrap; gap:16px;">
      <div>
        <h2 style="font-size:1.75rem; font-weight:800; color:var(--neutral-900);">Dashboard Pengelolaan DTKS & Bansos</h2>
        <p style="color:var(--neutral-600); font-size:0.9rem;">Kelola data penerima bantuan sosial, jenis program, usulan warga, dan pengaduan masyarakat.</p>
      </div>
      <div style="display:flex; gap:12px;">
        <button class="btn btn-outline" onclick="exportToCSV()">📥 Export Data CSV</button>
        <button class="btn btn-amber" onclick="openModal('modal-add-program')">🎁 Tambah Program Bansos</button>
        <button class="btn btn-primary" onclick="openModal('modal-add')">➕ Tambah Data Penerima</button>
      </div>
    </div>

    <!-- Navigation Tabs -->
    <div class="tabs-header">
      <button class="tab-btn active" data-tab="tab-overview">📊 Ringkasan & Grafik</button>
      <button class="tab-btn" data-tab="tab-penerima">📋 Data Penerima (DTKS)</button>
      <button class="tab-btn" data-tab="tab-program">🎁 Kelola Program Bansos</button>
      <button class="tab-btn" data-tab="tab-usulan">📝 Usulan Mandiri Warga</button>
      <button class="tab-btn" data-tab="tab-pengaduan">🚨 Posko Pengaduan</button>
    </div>

    <!-- TAB 1: OVERVIEW & STATS -->
    <div class="tab-pane active" id="tab-overview">
      <div class="stats-grid" style="margin-top:0; margin-bottom:30px;">
        <div class="stat-card">
          <div class="stat-icon green">👥</div>
          <div class="stat-info">
            <h4>86.250</h4>
            <p>Total Penerima KPM</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon amber">⏳</div>
          <div class="stat-info">
            <h4>1.240</h4>
            <p>Verifikasi Pending</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon blue">📦</div>
          <div class="stat-info">
            <h4>4 Program</h4>
            <p>Bansos Aktif Salur</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon green">🚨</div>
          <div class="stat-info">
            <h4>12 Ticket</h4>
            <p>Pengaduan Baru</p>
          </div>
        </div>
      </div>

      <!-- Charts Grid -->
      <div style="display:grid; grid-template-columns: 1.3fr 0.7fr; gap:24px;">
        <div style="background:white; padding:24px; border-radius:16px; border:1px solid #e2e8f0; box-shadow:var(--shadow-sm);">
          <h4 style="margin-bottom:16px; font-weight:700;">Distribusi KPM Penerima Bansos per Kecamatan</h4>
          <canvas id="chartKecamatan" height="170"></canvas>
        </div>

        <div style="background:white; padding:24px; border-radius:16px; border:1px solid #e2e8f0; box-shadow:var(--shadow-sm);">
          <h4 style="margin-bottom:16px; font-weight:700;">Persentase per Program Bansos</h4>
          <canvas id="chartProgram" height="200"></canvas>
        </div>
      </div>
    </div>

    <!-- TAB 2: DATA PENERIMA DTKS -->
    <div class="tab-pane" id="tab-penerima">
      <div style="background:white; padding:20px; border-radius:12px; margin-bottom:20px; border:1px solid #e2e8f0; display:flex; gap:16px; flex-wrap:wrap;">
        <input type="text" id="admin-search-input" class="form-control" style="max-width:300px;" placeholder="Cari NIK / Nama / Gampong..." onkeyup="loadAdminPenerimaTable()">
        <select id="admin-filter-kecamatan" class="form-control" style="max-width:220px;" onchange="loadAdminPenerimaTable()">
          <option value="">-- Semua Kecamatan --</option>
          <option value="Kota Juang">Kota Juang</option>
          <option value="Peusangan">Peusangan</option>
          <option value="Samalanga">Samalanga</option>
          <option value="Gandapura">Gandapura</option>
          <option value="Juli">Juli</option>
          <option value="Peudada">Peudada</option>
        </select>
        <select id="admin-filter-program" class="form-control" style="max-width:220px;" onchange="loadAdminPenerimaTable()">
          <option value="">-- Semua Program --</option>
          <option value="PKH">PKH</option>
          <option value="BPNT">BPNT</option>
          <option value="BLT-DD">BLT-DD</option>
          <option value="BANSOS-PANGAN">Bansos Pangan</option>
        </select>
      </div>

      <div class="table-responsive">
        <table class="data-table" id="admin-penerima-table">
          <thead>
            <tr>
              <th>No</th>
              <th>NIK KTP</th>
              <th>Nama Lengkap</th>
              <th>Kecamatan (Gampong)</th>
              <th>Program</th>
              <th>Verifikasi</th>
              <th>Penyaluran</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody id="admin-penerima-tbody">
            <!-- Rendered by JS -->
          </tbody>
        </table>
      </div>
    </div>

    <!-- TAB 3: KELOLA PROGRAM BANSOS -->
    <div class="tab-pane" id="tab-program">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
        <h3 style="font-weight:700;">Daftar Program Bantuan Sosial Aktif & Rencana Salur</h3>
        <button class="btn btn-amber btn-sm" onclick="openModal('modal-add-program')">➕ Buat Program Baru</button>
      </div>

      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Kode</th>
              <th>Nama Program Bantuan</th>
              <th>Penyelenggara</th>
              <th>Nominal Bantuan</th>
              <th>Periode Salur</th>
              <th>Kuota KPM</th>
              <th>Status</th>
              <th>Aksi Admin</th>
            </tr>
          </thead>
          <tbody id="admin-program-tbody">
            <!-- Rendered dynamically by JS -->
          </tbody>
        </table>
      </div>
    </div>

    <!-- TAB 4: USULAN MANDIRI -->
    <div class="tab-pane" id="tab-usulan">
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>No Usulan</th>
              <th>NIK / Pengusul</th>
              <th>Kontak HP</th>
              <th>Kecamatan & Gampong</th>
              <th>Program Diusulkan</th>
              <th>Alasan Pengajuan</th>
              <th>Status Usulan</th>
              <th>Aksi Admin</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><code>USL-202608-001</code></td>
              <td><strong>Munawar Abdullah</strong><br><small>NIK: 1111010101900009</small></td>
              <td>085260112233</td>
              <td>Kota Juang (Geudong-Geudong)</td>
              <td><span class="program-tag">PKH</span></td>
              <td><small>Sakit menahun dan menanggung 4 anak sekolah.</small></td>
              <td><span class="badge badge-warning">Menunggu Verifikasi</span></td>
              <td>
                <button class="btn btn-primary btn-sm" onclick="showToast('Usulan disetujui untuk dikirim verifikator', 'success')">Setujui</button>
                <button class="btn btn-outline btn-sm" style="color:#ef4444;" onclick="showToast('Usulan ditolak', 'info')">Tolak</button>
              </td>
            </tr>
            <tr>
              <td><code>USL-202608-002</code></td>
              <td><strong>Syarifah Hanum</strong><br><small>NIK: 1111020203880007</small></td>
              <td>081269887766</td>
              <td>Peusangan (Paya Lipah)</td>
              <td><span class="program-tag">BPNT</span></td>
              <td><small>Belum pernah mendapat bantuan sosial dan lansia tunggal.</small></td>
              <td><span class="badge badge-success">Disetujui</span></td>
              <td><small style="color:#10b981; font-weight:700;">✅ Terverifikasi</small></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- TAB 5: POSKO PENGADUAN -->
    <div class="tab-pane" id="tab-pengaduan">
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Ticket ID</th>
              <th>Pelapor</th>
              <th>Kategori</th>
              <th>Kecamatan</th>
              <th>Isi Laporan Pengaduan</th>
              <th>Status Ticket</th>
              <th>Aksi Response</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><code>TCK-88201</code></td>
              <td><strong>Hasan Basri</strong><br><small>082361009988</small></td>
              <td><span class="badge badge-warning">Bantuan Belum Cair</span></td>
              <td>Samalanga</td>
              <td><small>Saldo KKS BPNT belum terisi bulan Juli 2026.</small></td>
              <td><span class="badge badge-info">Diproses</span></td>
              <td><button class="btn btn-outline btn-sm" onclick="showToast('Tanggapan dikirim ke whatsapp pelapor', 'info')">💬 Tanggapi</button></td>
            </tr>
            <tr>
              <td><code>TCK-88202</code></td>
              <td><strong>Rahmat Hidayat</strong><br><small>rahmathdyt@gmail.com</small></td>
              <td><span class="badge badge-danger">Salah Sasaran</span></td>
              <td>Kota Juang</td>
              <td><small>Mohon verifikasi ulang data penerima BLT di gampong kami.</small></td>
              <td><span class="badge badge-success">Selesai</span></td>
              <td><small style="color:#10b981; font-weight:700;">✅ Musdes Ulang Done</small></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

  </div>

  <!-- MODAL TAMBAH DATA PENERIMA BANSOS -->
  <div class="modal-overlay" id="modal-add">
    <div class="modal-card">
      <div class="modal-header">
        <h3 style="font-weight:700;">Tambah Data Penerima Bansos (DTKS)</h3>
        <button class="modal-close" onclick="closeModal('modal-add')">&times;</button>
      </div>
      <form id="form-add-penerima">
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
          <div class="form-group">
            <label class="form-label">NIK KTP (16 Digit)</label>
            <input type="text" id="add-nik" class="form-control" required placeholder="111101xxxxxxxxxx" maxlength="16">
          </div>
          <div class="form-group">
            <label class="form-label">No. KK (16 Digit)</label>
            <input type="text" id="add-nkk" class="form-control" required placeholder="111101xxxxxxxxxx" maxlength="16">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Nama Lengkap Penerima</label>
          <input type="text" id="add-nama" class="form-control" required placeholder="Nama Lengkap KPM">
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
          <div class="form-group">
            <label class="form-label">Jenis Kelamin</label>
            <select id="add-jk" class="form-control" required>
              <option value="L">Laki-Laki</option>
              <option value="P">Perempuan</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Program Bansos</label>
            <select id="add-program" class="form-control" required>
              <option value="PKH">PKH</option>
              <option value="BPNT">BPNT (Sembako)</option>
              <option value="BLT-DD">BLT Dana Desa</option>
              <option value="BANSOS-PANGAN">Bansos Pangan</option>
            </select>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
          <div class="form-group">
            <label class="form-label">Kecamatan</label>
            <select id="add-kecamatan" class="form-control" required>
              <option value="Kota Juang">Kota Juang</option>
              <option value="Peusangan">Peusangan</option>
              <option value="Samalanga">Samalanga</option>
              <option value="Gandapura">Gandapura</option>
              <option value="Juli">Juli</option>
              <option value="Peudada">Peudada</option>
              <option value="Jeunieb">Jeunieb</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Gampong / Desa</label>
            <input type="text" id="add-gampong" class="form-control" required placeholder="Nama Gampong">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Alamat Lengkap</label>
          <input type="text" id="add-alamat" class="form-control" required placeholder="Dusun / Jalan">
        </div>

        <div style="display:flex; justify-content:flex-end; gap:12px; margin-top:20px;">
          <button type="button" class="btn btn-outline" onclick="closeModal('modal-add')">Batal</button>
          <button type="submit" class="btn btn-primary">Simpan Data KPM</button>
        </div>
      </form>
    </div>
  </div>

  <!-- MODAL TAMBAH PROGRAM BANSOS BARU -->
  <div class="modal-overlay" id="modal-add-program">
    <div class="modal-card">
      <div class="modal-header">
        <h3 style="font-weight:700;">🎁 Tambah Program Bantuan Sosial Baru</h3>
        <button class="modal-close" onclick="closeModal('modal-add-program')">&times;</button>
      </div>
      <form id="form-add-program">
        <div style="display:grid; grid-template-columns:1fr 2fr; gap:14px;">
          <div class="form-group">
            <label class="form-label">Kode Program</label>
            <input type="text" id="prog-kode" class="form-control" required placeholder="Contoh: BLT-ELNINO" style="text-transform:uppercase;">
          </div>
          <div class="form-group">
            <label class="form-label">Nama Program Bansos</label>
            <input type="text" id="prog-nama" class="form-control" required placeholder="Contoh: Bantuan Langsung Tunai El Nino">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Instansi Penyelenggara</label>
          <input type="text" id="prog-penyelenggara" class="form-control" required placeholder="Contoh: Kementerian Sosial RI / Dinsos Bireuen">
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
          <div class="form-group">
            <label class="form-label">Nominal Bantuan</label>
            <input type="text" id="prog-nominal" class="form-control" required placeholder="Contoh: Rp 400.000 / Tahap">
          </div>
          <div class="form-group">
            <label class="form-label">Periode Salur</label>
            <input type="text" id="prog-periode" class="form-control" required placeholder="Contoh: Triwulan / Setiap Bulan">
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
          <div class="form-group">
            <label class="form-label">Kuota KPM Kabupaten</label>
            <input type="number" id="prog-kuota" class="form-control" required placeholder="5000">
          </div>
          <div class="form-group">
            <label class="form-label">Status Program</label>
            <select id="prog-status" class="form-control" required>
              <option value="Aktif">Aktif</option>
              <option value="Non-Aktif">Non-Aktif</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Deskripsi & Syarat Kriteria</label>
          <textarea id="prog-deskripsi" class="form-control" rows="3" placeholder="Deskripsi sasaran penerima manfaat program..."></textarea>
        </div>

        <div style="display:flex; justify-content:flex-end; gap:12px; margin-top:20px;">
          <button type="button" class="btn btn-outline" onclick="closeModal('modal-add-program')">Batal</button>
          <button type="submit" class="btn btn-amber">Simpan Program Bansos</button>
        </div>
      </form>
    </div>
  </div>

  <script src="assets/js/main.js"></script>
</body>
</html>
