<?php
/**
 * Konfigurasi Database & Aplikasi SI BANSOS Kabupaten Bireuen
 * Siap Upload ke Web Hosting (cPanel / Shared Hosting / VPS)
 */

// Konfigurasi Database MySQL
define('DB_HOST', 'localhost');
define('DB_USER', 'root');           // Ubah sesuai username database hosting Anda
define('DB_PASS', '');               // Ubah sesuai password database hosting Anda
define('DB_NAME', 'db_sibansos_bireuen'); // Ubah sesuai nama database hosting Anda

// Pengaturan Aplikasi
define('APP_NAME', 'SI-BANSOS Kabupaten Bireuen');
define('APP_TAGLINE', 'Sistem Informasi Data Terpadu Kesejahteraan Sosial & Penyaluran Bantuan Sosial');
define('DISTRICT_NAME', 'Kabupaten Bireuen');
define('PROVINCE_NAME', 'Aceh');

// Function Koneksi Database PDO
function getDBConnection() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Jika koneksi database gagal, kembalikan null (frontend akan memakai fallback client storage/mock data secara otomatis)
            return null;
        }
    }
    return $pdo;
}

// Security Response Headers
header("X-XSS-Protection: 1; mode=block");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
?>
